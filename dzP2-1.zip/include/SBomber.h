#pragma once

#include <vector>

#include "LevelGUI.h"
#include "Plane.h"
#include "Bomb.h"
#include "Ground.h"
#include "Tank.h"

class SBomber
{
public:

    SBomber();
    ~SBomber();
    
    inline bool GetExitFlag() const { return exitFlag; }

    void ProcessKBHit();
    void TimeStart();
    void TimeFinish();

    void DrawFrame();
    void MoveObjects();
    void CheckObjects();

private:

    class AbstractCommand
    {
    public:
        virtual ~AbstractCommand() {};
        virtual void execute() =0;
    protected:
        AbstractCommand(SBomber* pCommand):pvoid( pCommand) {};
        SBomber* pvoid;
    };

    class DropBombCommand: public AbstractCommand
    {
       public:
        DropBombCommand(SBomber* pCommand) : AbstractCommand(pCommand) {};
        virtual void execute() override {
          pvoid->DropBomb();
        };
    };

    class DeleteDynamicObjCommand: public AbstractCommand
    {
    private:
        DynamicObject* p;
    public:
        DeleteDynamicObjCommand(SBomber* pCommand, DynamicObject* pB) : AbstractCommand(pCommand), p (pB) {};
        virtual void execute() override {
            pvoid->DeleteDynamicObj(p);
        }
    };


    class DeleteStaticObjCommand: public AbstractCommand
    {
    private:
        DestroyableGroundObject* p;
    public:
        DeleteStaticObjCommand(SBomber* pCommand, DestroyableGroundObject* pB) : AbstractCommand(pCommand), p (pB) {};
        virtual void execute() override{
            pvoid->DeleteStaticObj(p);
        }
    };

    void CommandExecuter(AbstractCommand * pCommand);

    void CheckPlaneAndLevelGUI();
    void CheckBombsAndGround();
    void  CheckDestoyableObjects(Bomb* pBomb);

    void  DeleteDynamicObj(DynamicObject * pBomb);
    void  DeleteStaticObj(GameObject* pObj);

    Ground * FindGround() const;
    Plane * FindPlane() const;
    LevelGUI * FindLevelGUI() const;
    std::vector<DestroyableGroundObject*> FindDestoyableGroundObjects() const;
    std::vector<Bomb*> FindAllBombs() const;

    void DropBomb();

    std::vector<DynamicObject*> vecDynamicObj;
    std::vector<GameObject*> vecStaticObj;
    
    bool exitFlag;

    uint64_t startTime, finishTime, passedTime;
    uint16_t bombsNumber, deltaTime, fps;
    int16_t score;
};

