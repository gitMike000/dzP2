#pragma once

enum CraterSize { SMALL_CRATER_SIZE = 9 };
